###############################################################################
# File name: readme.txt
# Created By: The Uniform Server Development Team
# 18-3-2013
###############################################################################

 Folder UniServerZ\home\us_config is a repository for the following two files. 
  .htaccess and  favicon.ico
 These files are copied to each new Vhost created.

 Folder UniServerZ\home\us_config also contains general server configuration
 information in file us_config.ini

 Note: This is in addition to the main configuration file user
      _configuration.bat located in folder UniServerZ\utils



