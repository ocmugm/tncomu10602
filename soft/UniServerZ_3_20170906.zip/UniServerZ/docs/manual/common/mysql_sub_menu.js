document.write('<span class=\"sub_menu_header\">Menu - MySQL</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p710\"><a href=\"mysql_change_password.html\"  target=\"_top\"         >Change Password</a></li>');
document.write('<li class=\"p720\"><a href=\"mysql_restore_password.html\"  target=\"_top\"        >Restore Password</a></li>');
document.write('<li class=\"p730\"><a href=\"mysql_create_delete_database.html\"  target=\"_top\"  >Create Delete Database</a></li>');
document.write('<li class=\"p740\"><a href=\"mysql_create_restricted_user.html\"  target=\"_top\"  >Create Restricted User</a></li>');
document.write('<li class=\"p750\"><a href=\"mysql_edit_restricted_user.html\"  target=\"_top\"    >Edit Restricted User</a></li>');
document.write('<li class=\"p760\"><a href=\"mysql_database_backup_restore.html\"  target=\"_top\" >Database backup/restore</a></li>');

document.write('</ul>');
document.write('</div>');
