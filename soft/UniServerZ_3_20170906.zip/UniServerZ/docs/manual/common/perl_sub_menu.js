
document.write('<span class=\"sub_menu_header\">Menu - Perl</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p910\"><a href=\"perl_install.html\"  target=\"_top\">Installing Perl</a></li>');
document.write('<li class=\"p920\"><a href=\"perl_unix_windows_shebang.html\"  target=\"_top\">Unix Shebang on Windows</a></li>');
document.write('<li class=\"p930\"><a href=\"perl_cli.html\"  target=\"_top\">Perl CLI</a></li>');

document.write('</ul>');
document.write('</div>');
